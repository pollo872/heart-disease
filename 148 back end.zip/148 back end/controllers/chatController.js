// console.log('🔑 GROQ KEY:', process.env.GROQ_API_KEY ? 'Found ✅' : 'MISSING ❌');

// const axios = require('axios');

// const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
// const GROQ_MODEL = 'llama-3.3-70b-versatile';// Fast & free model on Groq

// const SYSTEM_PROMPT = `You are a Heart Health Assistant. You specialize in answering questions about:
// - Heart health and cardiovascular wellness
// - Prevention of heart disease
// - Healthy lifestyle choices for a strong heart
// - Blood pressure management
// - Cholesterol and diet advice
// - Exercise recommendations for heart health
// - Heart disease risk factors

// Always respond in a friendly, supportive, and professional tone. 
// If the user writes in Arabic, respond in Arabic. If in English, respond in English.
// Keep your answers clear, concise, and helpful. 
// If a question is outside your expertise (heart health), politely redirect the user to ask about heart-related topics.
// Never provide emergency medical advice — always recommend calling emergency services in urgent situations.`;

// const sendMessage = async (req, res) => {
//   try {
//     const { message, conversationHistory = [] } = req.body;

//     if (!message || message.trim() === '') {
//       return res.status(400).json({ error: 'Message is required' });
//     }

//     // Build messages array with history
//     const messages = [
//       { role: 'system', content: SYSTEM_PROMPT },
//       ...conversationHistory,
//       { role: 'user', content: message },
//     ];

//     const response = await axios.post(
//       GROQ_API_URL,
//       {
//         model: GROQ_MODEL,
//         messages: messages,
//         max_tokens: 1024,
//         temperature: 0.7,
//       },
//       {
//         headers: {
//           Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
//           'Content-Type': 'application/json',
//         },
//       }
//     );

//     const assistantMessage = response.data.choices[0].message.content;

//     return res.status(200).json({
//       success: true,
//       message: assistantMessage,
//       usage: response.data.usage,
//     });
//   } catch (error) {
//     console.error('Groq API Error:', error?.response?.data || error.message);

//     if (error?.response?.status === 401) {
//       return res.status(401).json({ error: 'Invalid Groq API key' });
//     }
//     if (error?.response?.status === 429) {
//       return res.status(429).json({ error: 'Rate limit exceeded, please try again later' });
//     }

//     return res.status(500).json({ error: 'Failed to get response from AI assistant' });
//   }
// };

// module.exports = { sendMessage };

console.log('🔑 GROQ KEY:', process.env.GROQ_API_KEY ? 'Found ✅' : 'MISSING ❌');
console.log('🔑 OPENROUTER KEY:', process.env.OPENROUTER_API_KEY ? 'Found ✅' : 'MISSING ❌');

const axios = require('axios');

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_MODEL = 'llama-3.3-70b-versatile';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const VISION_MODEL = 'openrouter/free';

const SYSTEM_PROMPT = `You are a Heart Health Assistant. You specialize in answering questions about:
- Heart health and cardiovascular wellness
- Prevention of heart disease
- Healthy lifestyle choices for a strong heart
- Blood pressure management
- Cholesterol and diet advice
- Exercise recommendations for heart health
- Heart disease risk factors

When analyzing medical images (ECG, X-rays, lab results, reports):
- Provide a clear structured medical analysis
- Highlight any concerning findings
- Explain results in simple terms the patient can understand
- Always recommend consulting a doctor for official diagnosis
- Be thorough but compassionate

Always respond in a friendly, supportive, and professional tone.
If the user writes in Arabic, respond in Arabic. If in English, respond in English.
Never provide emergency medical advice — always recommend calling emergency services in urgent situations.`;

// ─────────────────────────────────────────────
// TEXT ONLY → Groq (fast & free)
// ─────────────────────────────────────────────
const handleTextMessage = async (message, conversationHistory) => {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: 'user', content: message },
  ];

  const response = await axios.post(
    GROQ_API_URL,
    { model: GROQ_MODEL, messages, max_tokens: 1024, temperature: 0.7 },
    {
      headers: {
        Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data.choices[0].message.content;
};

// ─────────────────────────────────────────────
// IMAGE / PDF → OpenRouter free router
// ─────────────────────────────────────────────
const handleMediaMessage = async (message, base64Data, mediaType, conversationHistory) => {
  const userText = message?.trim() ||
    (mediaType === 'application/pdf'
      ? 'Please analyze this medical document and provide a detailed heart health report.'
      : 'Please analyze this medical image and provide a detailed heart health report.');

  const userContent = [
    {
      type: 'image_url',
      image_url: { url: `data:${mediaType};base64,${base64Data}` },
    },
    { type: 'text', text: userText },
  ];

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: 'user', content: userContent },
  ];

  const response = await axios.post(
    OPENROUTER_API_URL,
    { model: VISION_MODEL, messages, max_tokens: 2048, temperature: 0.7 },
    {
      headers: {
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'http://localhost:5001',
        'X-Title': 'EchoHealth Heart Assistant',
      },
      timeout: 30000,
    }
  );

  return response.data.choices[0].message.content;
};

// ─────────────────────────────────────────────
// MAIN CONTROLLER
// ─────────────────────────────────────────────
const sendMessage = async (req, res) => {
  try {
    const {
      message = '',
      conversationHistory = [],
      fileData,
      fileType,
    } = req.body;

    if (!message.trim() && !fileData) {
      return res.status(400).json({ error: 'Message or file is required' });
    }

    let assistantMessage;

    if (fileData && fileType) {
      console.log(`📎 File received: ${fileType} → routing to OpenRouter (free)`);
      assistantMessage = await handleMediaMessage(message, fileData, fileType, conversationHistory);
    } else {
      console.log('💬 Text only → routing to Groq');
      assistantMessage = await handleTextMessage(message, conversationHistory);
    }

    return res.status(200).json({ success: true, message: assistantMessage });
  } catch (error) {
    console.error('Chat Error:', error?.response?.data || error.message);
    const status = error?.response?.status;
    if (status === 401 || status === 403) {
      return res.status(401).json({ error: 'Invalid API key' });
    }
    if (status === 429) {
      return res.status(429).json({ error: 'Rate limit exceeded, please try again later' });
    }
    return res.status(500).json({ error: 'Failed to get response from AI assistant' });
  }
};

module.exports = { sendMessage };