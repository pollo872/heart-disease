// // controllers/healthDataController.js
// const HealthData = require('../models/HealthData');
// const axios = require('axios');
// const responseHandler = require('../utils/responseHandler');
// exports.submitHealthData = async (req, res) => {
//   try {
//     const patientId = req.patient.id;

//     const healthDataBody = {
//       patient: patientId,
//       ...req.body
//     };

//     // أرسل البيانات إلى Flask API
//     const flaskResponse = await axios.post('http://127.0.0.1:5001/predict', {
//       BMI: req.body.BMI,
//       Smoking: req.body.Smoking,
//       AlcoholDrinking: req.body.AlcoholDrinking,
//       Stroke: req.body.Stroke,
//       PhysicalHealth: req.body.PhysicalHealth,
//       MentalHealth: req.body.MentalHealth,
//       DiffWalking: req.body.DiffWalking,
//       Sex: req.body.Sex,
//       AgeCategory: req.body.AgeCategory,
//       Race: req.body.Race,
//       Diabetic: req.body.Diabetic,
//       PhysicalActivity: req.body.PhysicalActivity,
//       GenHealth: req.body.GenHealth,
//       SleepTime: req.body.SleepTime,
//       Asthma: req.body.Asthma,
//       KidneyDisease: req.body.KidneyDisease,
//       SkinCancer: req.body.SkinCancer
//     });

//     const { prediction, probability, risk_level } = flaskResponse.data;

//     // أضف نتائج التنبؤ إلى البيانات التي سيتم حفظها
//     healthDataBody.predictionResult = prediction;
//     healthDataBody.probability = probability;
//     healthDataBody.riskLevel = risk_level;

//     const newHealthData = await HealthData.create(healthDataBody);

//     responseHandler(res, 201, true, 'Health data and prediction saved successfully', newHealthData);
//   } catch (error) {
//     console.error(error);
//     responseHandler(res, 500, false, 'Failed to save health data or predict', error.message);
//   }
// };

