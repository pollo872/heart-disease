const Patient = require('../models/Patient');
const HealthData = require('../models/HealthData');

// عرض بيانات المريض (الملف الشخصي)
exports.getPatientProfile = async (req, res) => {
  try {
    const patientId = req.patient.id;

    // جلب معلومات المريض
    const patient = await Patient.findById(patientId).select('-password');
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    // جلب آخر بيانات صحية (أو يمكنك استخدام .find({ patient: patientId }) لجلب الكل)
    const latestHealthData = await HealthData.findOne({ patient: patientId })
      .sort({ createdAt: -1 }); // الأحدث أولًا
    const allHealthData = await HealthData.find({ patient: patientId })
      .sort({ createdAt: -1 });
    res.status(200).json({
      patient,
      latestHealthData,
      allHealthData,
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};


// تعديل بيانات المريض
exports.updatePatient = async (req, res) => {
  try {
    const patientId = req.patient._id; // من التوكن
    const updateFields = req.body;

    const updatedPatient = await Patient.findByIdAndUpdate(
      patientId,
      updateFields,
      { new: true, runValidators: true }
    ).select('-password');

    if (!updatedPatient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    res.status(200).json({
      message: 'Patient updated successfully',
      patient: updatedPatient
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
