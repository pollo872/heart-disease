// // controllers/healthDataController.js
// const HealthData = require('../models/HealthData');
// const axios      = require('axios');
// const responseHandler = require('../utils/responseHandler');

// const FLASK_URL = process.env.FLASK_API_URL || 'http://127.0.0.1:5000';
// console.log('[Config] Using Flask API URL:', FLASK_URL);

// exports.submitHealthData = async (req, res) => {
//   try {
//     const patientId = req.patient.id;

//     // ── Validate required fields ──────────────────────────────────────────────
//     const required = [
//       'BMI', 'Smoking', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth',
//       'MentalHealth', 'DiffWalking', 'Sex', 'AgeCategory', 'Race',
//       'Diabetic', 'PhysicalActivity', 'GenHealth', 'SleepTime',
//       'Asthma', 'KidneyDisease', 'SkinCancer'
//     ];
//     const missing = required.filter(f => req.body[f] === undefined || req.body[f] === null);
//     if (missing.length > 0) {
//       return responseHandler(res, 400, false, `Missing fields: ${missing.join(', ')}`, null);
//     }

//     // ── Build payload — pass raw values, Flask handles all encoding ──────────
//     // NOTE: Flask's preprocess() converts Yes/No, computes Age & HighRisk,
//     //       encodes Diabetic, and validates Race — no transforms needed here.
//     const flaskPayload = {
//       BMI:              req.body.BMI,
//       Smoking:          req.body.Smoking,
//       AlcoholDrinking:  req.body.AlcoholDrinking,
//       Stroke:           req.body.Stroke,
//       PhysicalHealth:   req.body.PhysicalHealth,
//       MentalHealth:     req.body.MentalHealth,
//       DiffWalking:      req.body.DiffWalking,
//       Sex:              req.body.Sex,
//       AgeCategory:      req.body.AgeCategory,
//       Race:             req.body.Race,
//       Diabetic:         req.body.Diabetic,
//       PhysicalActivity: req.body.PhysicalActivity,
//       GenHealth:        req.body.GenHealth,
//       SleepTime:        req.body.SleepTime,
//       Asthma:           req.body.Asthma,
//       KidneyDisease:    req.body.KidneyDisease,
//       SkinCancer:       req.body.SkinCancer,
//     };

//     console.log('[ML] Sending to Flask →', JSON.stringify(flaskPayload));

//     // ── Call Flask ────────────────────────────────────────────────────────────
//     const flaskResponse = await axios.post(`${FLASK_URL}/predict`, flaskPayload, {
//       timeout: 10000,
//     });

//     const { prediction, probability, risk_level, at_risk } = flaskResponse.data;
//     console.log('[ML] Flask response ←', flaskResponse.data);

//     // ── Save to DB ────────────────────────────────────────────────────────────
//     const newHealthData = await HealthData.create({
//       patient:          patientId,
//       ...req.body,
//       predictionResult: prediction,
//       probability:      probability,
//       riskLevel:        risk_level,
//       // atRisk:           at_risk,
//     });

//     responseHandler(res, 201, true, 'Health data saved and prediction complete', newHealthData);

//   } catch (error) {
//     if (error.code === 'ECONNREFUSED') {
//       console.error('[ML] Flask server unreachable at', FLASK_URL);
//       return responseHandler(res, 503, false, 'ML service unavailable. Is Flask running?', null);
//     }
//     console.error('[submitHealthData]', error.message);
//     responseHandler(res, 500, false, 'Failed to process health data', error.message);
//   }
// };


console.log('🔑 GEMINI KEY:', process.env.GEMINI_API_KEY ? 'Found ✅' : 'MISSING ❌');
const HealthData = require('../models/HealthData');
const axios = require('axios');
const responseHandler = require('../utils/responseHandler');

const FLASK_URL = process.env.FLASK_API_URL || 'http://127.0.0.1:5000';
console.log('[Config] Using Flask API URL:', FLASK_URL);

exports.submitHealthData = async (req, res) => {
  try {
    const patientId = req.patient.id;

    // ── Validate required fields ──────────────────────────────────────────────
    const required = [
      'BMI', 'Smoking', 'AlcoholDrinking', 'BrainStroke', 'PhysicalHealth',
      'MentalHealth', 'DiffWalking', 'Sex', 'AgeCategory', 'Race',
      'Diabetic', 'PhysicalActivity', 'GenHealth', 'SleepTime',
      'Asthma', 'KidneyDisease', 'CancerHistory', 'ChronicHypertension', 'LiverDisease',
      'ImmunologicalDiseases', 'MyocardialInfarctionInHeart', 'SystolicBP', 'DiastolicBP', 'BloodSugar', 'Cholesterol', 'CaffeineIntake',
    ];
    const missing = required.filter(f => req.body[f] === undefined || req.body[f] === null);
    if (missing.length > 0) {
      return responseHandler(res, 400, false, `Missing fields: ${missing.join(', ')}`, null);
    }

    const flaskPayload = {
      BMI: req.body.BMI,
      Smoking: req.body.Smoking,
      AlcoholDrinking: req.body.AlcoholDrinking,
      BrainStroke: req.body.BrainStroke,
      PhysicalHealth: req.body.PhysicalHealth,
      MentalHealth: req.body.MentalHealth,
      DiffWalking: req.body.DiffWalking,
      Sex: req.body.Sex,
      AgeCategory: req.body.AgeCategory,
      Race: req.body.Race,
      Diabetic: req.body.Diabetic,
      PhysicalActivity: req.body.PhysicalActivity,
      GenHealth: req.body.GenHealth,
      SleepTime: req.body.SleepTime,
      Asthma: req.body.Asthma,
      KidneyDisease: req.body.KidneyDisease,
      CancerHistory: req.body.CancerHistory,
      ChronicHypertension: req.body.ChronicHypertension,
      LiverDisease: req.body.LiverDisease,
      ImmunologicalDiseases: req.body.ImmunologicalDiseases,
      MyocardialInfarctionInHeart: req.body.MyocardialInfarctionInHeart,
      SystolicBP: req.body.SystolicBP,
      DiastolicBP: req.body.DiastolicBP,
      BloodSugar: req.body.BloodSugar,
      Cholesterol: req.body.Cholesterol,
      CaffeineIntake: req.body.CaffeineIntake, // Default to 0 if not provided

    };

    console.log('[ML] Sending to Flask →', JSON.stringify(flaskPayload));

    const flaskResponse = await axios.post(`${FLASK_URL}/predict`, flaskPayload, {
      timeout: 30000, // زودنا الـ timeout لأن Gemini بياخد وقت أكتر
    });

    const { prediction, probability, risk_level,dP_level,suger_level,cholesterol_level, ai_analysis } = flaskResponse.data;
    console.log('[ML] Flask response ←', flaskResponse.data);

    // ── Save to DB ────────────────────────────────────────────────────────────
    const newHealthData = await HealthData.create({
      patient: patientId,
      ...req.body,
      predictionResult: prediction,
      probability: probability,
      riskLevel: risk_level,
      dPLevel:dP_level,
      sugerLevel:suger_level,
      cholesterolLevel:cholesterol_level,
      aiAnalysis: ai_analysis || null,
    });

    responseHandler(res, 201, true, 'Health data saved and prediction complete', newHealthData);

  } catch (error) {
    if (error.code === 'ECONNREFUSED') {
      console.error('[ML] Flask server unreachable at', FLASK_URL);
      return responseHandler(res, 503, false, 'ML service unavailable. Is Flask running?', null);
    }
    console.error('[submitHealthData]', error.message);
    responseHandler(res, 500, false, 'Failed to process health data', error.message);
  }
};