console.log('🔑 GROQ KEY:', process.env.GROQ_API_KEY ? 'Found ✅' : 'MISSING ❌');
console.log('🔑 GEMINI KEY:', process.env.GEMINI_API_KEY ? 'Found ✅' : 'MISSING ❌');

const axios = require('axios');

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_MODEL = 'llama-3.3-70b-versatile';

const SYSTEM_PROMPT = `You are a Heart Health Assistant. You specialize in answering questions about:
- Heart health and cardiovascular wellness
- Prevention of heart disease
- Healthy lifestyle choices for a strong heart
- Blood pressure management
- Cholesterol and diet advice
- Exercise recommendations for heart health
- Heart disease risk factors

When analyzing medical images (ECG, X-rays, lab results, reports):
- Provide a clear structured medical analysis
- Highlight any concerning findings
- Explain results in simple terms the patient can understand
- Always recommend consulting a doctor for official diagnosis
- Be thorough but compassionate

Always respond in a friendly, supportive, and professional tone.
If the user writes in Arabic, respond in Arabic. If in English, respond in English.
Never provide emergency medical advice — always recommend calling emergency services in urgent situations.`;

// ─────────────────────────────────────────────
// TEXT ONLY → Groq (fast & free)
// ─────────────────────────────────────────────
const handleTextMessage = async (message, conversationHistory) => {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: 'user', content: message },
  ];

  const response = await axios.post(
    GROQ_API_URL,
    { model: GROQ_MODEL, messages, max_tokens: 1024, temperature: 0.7 },
    {
      headers: {
        Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data.choices[0].message.content;
};

// ─────────────────────────────────────────────
// IMAGE / PDF → Gemini (free & powerful)
// ─────────────────────────────────────────────
const handleMediaMessage = async (message, base64Data, mediaType) => {
  const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`;

  const userText = message?.trim() ||
    (mediaType === 'application/pdf'
      ? 'Please analyze this medical document and provide a detailed heart health report.'
      : 'Please analyze this medical image and provide a detailed heart health report.');

  // Build the parts array
  const parts = [
    {
      inline_data: {
        mime_type: mediaType,
        data: base64Data,
      },
    },
    {
      text: userText,
    },
  ];

  const response = await axios.post(
    GEMINI_API_URL,
    {
      system_instruction: {
        parts: [{ text: SYSTEM_PROMPT }],
      },
      contents: [
        {
          role: 'user',
          parts,
        },
      ],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 2048,
      },
    },
    { headers: { 'Content-Type': 'application/json' } }
  );

  return response.data.candidates[0].content.parts[0].text;
};

// ─────────────────────────────────────────────
// MAIN CONTROLLER
// ─────────────────────────────────────────────
const sendMessage = async (req, res) => {
  try {
    const {
      message = '',
      conversationHistory = [],
      fileData,   // base64 string
      fileType,   // 'image/jpeg' | 'image/png' | 'image/webp' | 'application/pdf'
    } = req.body;

    if (!message.trim() && !fileData) {
      return res.status(400).json({ error: 'Message or file is required' });
    }

    let assistantMessage;

    if (fileData && fileType) {
      console.log(`📎 File received: ${fileType} → routing to Gemini`);
      assistantMessage = await handleMediaMessage(message, fileData, fileType);
    } else {
      console.log('💬 Text only → routing to Groq');
      assistantMessage = await handleTextMessage(message, conversationHistory);
    }

    return res.status(200).json({
      success: true,
      message: assistantMessage,
    });
  } catch (error) {
    console.error('Chat Error:', error?.response?.data || error.message);

    const status = error?.response?.status;

    if (status === 401 || status === 403) {
      return res.status(401).json({ error: 'Invalid API key' });
    }
    if (status === 429) {
      return res.status(429).json({ error: 'Rate limit exceeded, please try again later' });
    }

    return res.status(500).json({ error: 'Failed to get response from AI assistant' });
  }
};

module.exports = { sendMessage };
