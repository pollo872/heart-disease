// models/Patient.js
const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName:  { type: String, required: true },
  email:     { type: String, required: true, unique: true },
  password:  { type: String, required: true },
  phone:     { type: String },
  gender:    { type: String, enum: ['male', 'female'] },
  dob:       { type: Date },
  role:      { type: String, default: 'patient' }
}, { timestamps: true });

module.exports = mongoose.model('Patient', patientSchema);
