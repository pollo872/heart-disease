// routes/healthDataRoutes.js
const express = require('express');
const router = express.Router();
const healthDataController = require('../controllers/healthDataController1');
const authMiddleware = require('../middleware/authMiddleware');
const validate = require('../middleware/validateRequest');
const {healthDataValidation} = require('../validators/healthDataValidator');

// المريض فقط هو من يمكنه إرسال البيانات
router.post('/submit',authMiddleware,healthDataValidation ,validate, healthDataController.submitHealthData);

module.exports = router;