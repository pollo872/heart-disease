// routes/patientRoutes.js
const express = require('express');
const router = express.Router();
const { getPatientProfile, updatePatient } = require('../controllers/patientController');
const authMiddleware = require('../middleware/authMiddleware');
const validate = require('../middleware/validateRequest');
const {updateProfileValidation} = require('../validators/patientValidator');

router.get('/profile', authMiddleware, getPatientProfile);
router.put('/profile', authMiddleware,validate,updateProfileValidation, updatePatient);

module.exports = router;
