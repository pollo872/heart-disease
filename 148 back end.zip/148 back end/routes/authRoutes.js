const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { registerValidation, loginValidation } = require('../validators/authValidator');
const validate = require('../middleware/validateRequest');

router.post('/register', registerValidation, validate, authController.registerPatient);
router.post('/login', loginValidation, validate, authController.loginPatient);

module.exports = router;
