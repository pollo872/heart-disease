// middleware/authMiddleware.js
const jwt = require('jsonwebtoken');
const Patient = require('../models/Patient');

const protect = async (req, res, next) => {
  let token;

  // تحقق من وجود التوكن في الهيدر
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];

      // فك التوكن
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // جلب بيانات المريض بدون كلمة المرور
      const patient = await Patient.findById(decoded.id).select('-password');
      if (!patient) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      req.patient = patient; // نضع بيانات المريض في الطلب
      next(); // السماح بالوصول للراوت
    } catch (error) {
      return res.status(401).json({ message: 'Invalid token' });
    }
  } else {
    return res.status(401).json({ message: 'No token provided' });
  }
};

module.exports = protect;
