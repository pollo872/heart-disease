const mongoose = require('mongoose');

const healthDataSchema = new mongoose.Schema({
  patient: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient', required: true },

  BMI: Number,
  Smoking: { type: String, enum: ['Yes', 'No'] },
  AlcoholDrinking: { type: String, enum: ['Yes', 'No'] },
  BrainStroke: { type: String, enum: ['Yes', 'No'] },
  PhysicalHealth: Number,
  MentalHealth: Number,
  DiffWalking: { type: String, enum: ['Yes', 'No'] },
  Sex: { type: String, enum: ['Male', 'Female'] },
  AgeCategory: String,
  Race: String,
  Diabetic: String,
  PhysicalActivity: { type: String, enum: ['Yes', 'No'] },
  GenHealth: String,
  SleepTime: Number,
  Asthma: { type: String, enum: ['Yes', 'No'] },
  KidneyDisease: { type: String, enum: ['Yes', 'No'] },
  CancerHistory: { type: String, enum: ['Yes', 'No'] },
  ChronicHypertension: { type: String, enum: ['Yes', 'No'] },
  LiverDisease: { type: String, enum: ['Yes', 'No'] },
  ImmunologicalDiseases: { type: String, enum: ['Yes', 'No'] },
  MyocardialInfarctionInHeart: { type: String, enum: ['Yes', 'No'] },
  SystolicBP: Number,
  DiastolicBP: Number,
  BloodSugar: Number,
  Cholesterol: Number,
  CaffeineIntake: Number,


  predictionResult: { type: String, enum: ['At Risk', 'Not at Risk'], default: null },
  probability: { type: Number, default: null },
  riskLevel: { type: String, enum: ['Low', 'Medium', 'High'], default: null }
}, { timestamps: true });

module.exports = mongoose.model('HealthData', healthDataSchema);
