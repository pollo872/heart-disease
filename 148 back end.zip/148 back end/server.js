const dotenv = require('dotenv');
dotenv.config();

const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const patientRoutes = require('./routes/patientRoutes');
const healthDataRoutes = require('./routes/healthDataRoutes');
const chatRoutes = require('./routes/chatRoutes');




// Load env variables

// Connect to DB
connectDB();

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ limit: '20mb', extended: true }));
// app.use(express.json());

app.get('/', (req, res) => {
  res.send('EchoHealth API is running...');
});
app.use('/api/auth', authRoutes);
app.use('/api/patient', patientRoutes);
app.use('/api/health-data', healthDataRoutes);
app.use('/api/chat', chatRoutes);





const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});